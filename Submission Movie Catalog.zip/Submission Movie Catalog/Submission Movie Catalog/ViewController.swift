//
//  ViewController.swift
//  Submission Movie Catalog
//
//  Created by Ilham Rizki Baharsyah on 16/06/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var HomePageTableView: UITableView!
    
    private var viewModel = GamesViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadGamesData()
        
        }
    
    private func loadGamesData() {
        viewModel.fetchGamesListData{ [weak self] in
            self?.HomePageTableView.dataSource = self
            self?.HomePageTableView.delegate = self
            self?.HomePageTableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
            self?.HomePageTableView.reloadData()
        }
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        let game = viewModel.cellForRowAt(indexPath: indexPath)
        cell.setCellWithValuesOf(game)
        
        return cell
    }
}
