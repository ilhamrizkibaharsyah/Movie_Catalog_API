//
//  TableViewCell.swift
//  Submission Movie Catalog
//
//  Created by Ilham Rizki Baharsyah on 20/06/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var homePosterImage: UIImageView!
    @IBOutlet weak var homeNameGames: UILabel!
    @IBOutlet weak var starRatingLogo: UIImageView!
    @IBOutlet weak var ratingGames: UILabel!
    @IBOutlet weak var homeReleasedGames: UILabel!
    
    private var urlString: String = ""
    
    func setCellWithValuesOf(_ game: Game) {
        updateUI(id: game.id, name: game.name, released: game.released, backgroundImage: game.backgroundImage, rating: game.rating)
    }
    
    // Update the UI Views
    
    private func updateUI(id: Int?, name: String?, released: String?, backgroundImage: String?, rating: Double?) {
        self.homeNameGames.text = name
        self.homeReleasedGames.text = convertDateFormater(released)
        guard let rate = rating else {return}
        self.ratingGames.text = String(rate)
        guard let posterString = backgroundImage else {return}
        urlString = posterString
        guard let posterImageUrl = URL(string: urlString) else {
            self.homePosterImage.image = UIImage(named: "Error")
            return
        }
        
        self.homePosterImage.image = nil
        getImageDataFrom(url: posterImageUrl)
    }
    
    private func getImageDataFrom(url: URL) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                print("DataTask error: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                print("Empty Data")
                return
            }
            
            DispatchQueue.main.async {
                if let image = UIImage(data: data) {
                    self.homePosterImage.image = image
                }
            }
        }.resume()
    }
    
    func convertDateFormater(_ date: String?) -> String {
        var fixDate = ""
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        if let originalDate = date {
            if let newDate = dateFormatter.date(from: originalDate) {
                dateFormatter.dateFormat = "dd.MM.yyyy"
                fixDate = dateFormatter.string(from: newDate)
            }
        }
        return fixDate
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        starRatingLogo.image = UIImage(named: "Star_Rating")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
