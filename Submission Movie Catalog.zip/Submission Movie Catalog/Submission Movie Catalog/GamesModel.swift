//
//  MovieModel.swift
//  Submission Movie Catalog
//
//  Created by Ilham Rizki Baharsyah on 20/06/22.
//

import Foundation

struct GamesData: Decodable {
    let games: [Game]
    
    private enum CodingKeys: String, CodingKey {
        case games = "results"
    }
}

struct Game: Decodable {
    let id: Int?
    let name: String?
    let released: String?
    let backgroundImage: String?
    let rating: Double?
    
    private enum CodingKeys: String, CodingKey {
        case id, name, released, rating
        case backgroundImage = "background_image"
    }
}
