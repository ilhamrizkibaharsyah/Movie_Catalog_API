//
//  MovieViewModel.swift
//  Submission Movie Catalog
//
//  Created by Ilham Rizki Baharsyah on 20/06/22.
//

import Foundation

class GamesViewModel {
    var apiService = APIService()
    var gamesList = [Game]()
    
    func fetchGamesListData(completion: @escaping () -> ()) {
        
        apiService.getGamesListData { [weak self] (result) in
            
            switch result {
            case .success(let list):
                self?.gamesList = list.games
                completion()
            case.failure(let error):
                print("Error processing JSON Data: \(error)")
            }
        }
    }
    
    func numberOfRowsInSection(section: Int) -> Int {
        if gamesList.count != 0 {
            return gamesList.count
        }
        return 0
    }
    
    func cellForRowAt(indexPath: IndexPath) -> Game {
        return gamesList[indexPath.row]
    }
}
