//
//  API_RawgIO.swift
//  Submission Movie Catalog
//
//  Created by Ilham Rizki Baharsyah on 20/06/22.
//

import Foundation

class APIService {
    
    private var dataTask: URLSessionDataTask?
    
    func getGamesListData(completion: @escaping (Result<GamesData, Error>) -> Void) {
        
        let apiKey = "4a826afa875b4f0088fd9e931be51288"
        let page = "3"

        var components = URLComponents(string: "https://api.rawg.io/api/games")!

        components.queryItems = [
            URLQueryItem(name: "page", value: page),
            URLQueryItem(name: "key", value: apiKey)
        ]

        let request = URLRequest(url: components.url!)

        dataTask = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            // Handle Error
            if let error = error {
                completion(.failure(error))
                print("DataTask Error: \(error.localizedDescription)")
                return
            }
            
            guard let response = response as? HTTPURLResponse else {
                // Handle Empty Response
                print("Empty Response")
                return
            }
            print("Response status code: \(response.statusCode)")
            
            guard let data = data else {
                // Handle Empty Data
                print("Empty Data")
                return
            }
            
            do {
                // Parse the data
                let decoder = JSONDecoder()
                let jsonData = try decoder.decode(GamesData.self, from: data)
                
                DispatchQueue.main.async {
                    completion(.success(jsonData))
                }
            } catch let error {
                completion(.failure(error))
            }
        }
        dataTask?.resume()
    }
}
